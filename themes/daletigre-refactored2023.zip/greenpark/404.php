<?php get_header(); ?>
<!-- Container -->

<div class="CON">
  
  <!-- Start SC -->
  <div class="SC">
    <div class="SC_head">
      <div class="SC_foot"> 
      <h2 class="pagetitle">Erro 404</h2>
      <p>Página não encontrada!</p>
      <p align="center"><img src="http://www.daletigre.com/daletigre/fail.jpg" align="center"></p>
      </div>
    </div>
  </div>
</div>
<!-- End CON -->
<?php get_footer(); ?>
