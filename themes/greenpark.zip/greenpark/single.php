<?php get_header(); ?>
<!-- Container -->

<div class="CON">
  <!-- Start SC -->
  <div class="SC">
    <div class="SC_head">
      <div class="SC_foot">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="Post" id="post-<?php the_ID(); ?>">
      <div class="PostHead">
        <h2><a title="Link para a matéria: <?php the_title(); ?>" href="<?php the_permalink() ?>" rel="bookmark">
          <?php the_title(); ?>
          </a></h2>
<div class="PostDados">
<ul>
<li class="Dados1">
<a title="Link do artigo: <?php the_title(); ?>" href="<?php the_permalink() ?>" rel="bookmark"><?php the_time('j') ?> de <?php the_time('M') ?> de <?php the_time('Y') ?></a>
</li>

<li class="Dados2">
<?php the_author() ?>
</li>

<li class="Dados3">
<?php the_category(', ') ?>
</li>
</ul>
</div>
        <div class="clr"></div>
<center><?php advman_ad('post-cab'); ?></center>
      </div>

      <div class="PostContent">
        <?php the_content('<p class="serif">Clique aqui para continuar lendo &raquo;</p>'); ?><br>


<!--/* OpenX Javascript Tag v2.6.2 */-->

<!--/*
  * The backup image section of this tag has been generated for use on a
  * non-SSL page. If this tag is to be placed on an SSL page, change the
  *   'http://www.tigrelog.com.br/openx/www/delivery/...'
  * to
  *   'https://www.tigrelog.com.br/openx/www/delivery/...'
  *
  * This noscript section of this tag only shows image banners. There
  * is no width or height in these banners, so if you want these tags to
  * allocate space for the ad before it shows, you will need to add this
  * information to the <img> tag.
  *
  * If you do not want to deal with the intricities of the noscript
  * section, delete the tag (from <noscript>... to </noscript>). On
  * average, the noscript tag is called from less than 1% of internet
  * users.
  */-->

<script type='text/javascript'><!--//<![CDATA[
   var m3_u = (location.protocol=='https:'?'https://www.tigrelog.com.br/openx/www/delivery/ajs.php':'http://www.tigrelog.com.br/openx/www/delivery/ajs.php');
   var m3_r = Math.floor(Math.random()*99999999999);
   if (!document.MAX_used) document.MAX_used = ',';
   document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);
   document.write ("?campaignid=8");
   document.write ('&amp;cb=' + m3_r);
   if (document.MAX_used != ',') document.write ("&amp;exclude=" + document.MAX_used);
   document.write (document.charset ? '&amp;charset='+document.charset : (document.characterSet ? '&amp;charset='+document.characterSet : ''));
   document.write ("&amp;loc=" + escape(window.location));
   if (document.referrer) document.write ("&amp;referer=" + escape(document.referrer));
   if (document.context) document.write ("&context=" + escape(document.context));
   if (document.mmm_fo) document.write ("&amp;mmm_fo=1");
   document.write ("'><\/scr"+"ipt>");
//]]>--></script><noscript><a href='http://www.tigrelog.com.br/openx/www/delivery/ck.php?n=a3e90fcf&amp;cb=1991' target='_blank'><img src='http://www.tigrelog.com.br/openx/www/delivery/avw.php?campaignid=8&amp;cb=1991&amp;n=a3e90fcf' border='0' alt='' /></a></noscript>

        <p class="autoria">Leia mais textos de <?php the_author_posts_link(); ?>.</p>
        <?php wp_link_pages(array('before' => '<p><strong>Páginas:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
      </div>



    <div class="PostCom2" align="center">
<br>
<?php if(function_exists('the_ratings')) { the_ratings(); } ?>  
    </div>

<br><br>


    </div>

<?php if (('open' == $post-> comment_status) && ('open' == $post->ping_status)) {
// Both Comments and Pings are open ?><br>

    <?php } elseif (!('open' == $post-> comment_status) && ('open' == $post->ping_status)) {
// Only Pings are Open ?><br>
    <?php } elseif (('open' == $post-> comment_status) && !('open' == $post->ping_status)) {
// Comments are open, Pings are not ?>
    <?php } elseif (!('open' == $post-> comment_status) && !('open' == $post->ping_status)) {
// Neither Comments, nor Pings are open ?>
    <?php } edit_post_link('+Editar esta matéria', '<p class="edit_this">', '</p>'); ?>
    </span>
    <?php if ( comments_open() ) comments_template(); ?>
    <?php endwhile; else: ?>
    <p>Desculpe-nos, não existe nenhum texto nesta categoria.</p>
    <?php endif; ?>
      </div>
    </div>
  </div>
  <!-- End SC -->
  <?php get_sidebar(); ?>
  <div class="clr"></div>
</div>
<!-- End CON -->
<?php get_footer(); ?>
