// JavaScript Document

function changeSty(classpassed){
	element=event.srcElement;
	//document.getElementById('buttonIMG').className=classpassed;
	element.className=classpassed;
}