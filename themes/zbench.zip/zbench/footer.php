</div><!--wrapper-->
<div class="fixed"></div>
<div id="footer">
	<div id="footer-inside">
		<p>
			Copyright&nbsp;&copy;&nbsp;<?php echo date("Y"); ?>&nbsp;<?php bloginfo('name'); ?>
			&nbsp;|&nbsp;Powered by <a href="http://wordpress.org/">WordPress</a> 
			&nbsp;|&nbsp;Theme <a href="http://zww.me" title="designed by zwwooooo">zBench</a>
			&nbsp;|&nbsp;Valid <a href="http://validator.w3.org/check?uri=referer" title="This page validates as XHTML 1.1 Transitional"><abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a> and <a href="http://jigsaw.w3.org/css-validator/check/referer?profile=css3">CSS 3</a>
		</p>
		<span id="back-to-top">&Delta; <a href="#nav" rel="nofollow" title="Back to top">Top</a></span>
	</div>
</div><!--footer-->
<?php wp_footer(); ?>
</body>
</html>