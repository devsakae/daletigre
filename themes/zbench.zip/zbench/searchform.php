<form id="searchform" method="get" action="<?php bloginfo('home'); ?>/">
<input type="text" value="Search: type, hit enter" onfocus="if (this.value == 'Search: type, hit enter') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search: type, hit enter';}" size="35" maxlength="50" name="s" id="s" />
<input type="submit" id="searchsubmit" value="" />
</form>